<?php
$navigationLinks = require __DIR__ . '/site-pages.php';
?>
    <nav class="navbar navbar-expand-lg navbar-dark site-navbar">
        <div class="container-fluid px-4">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar" aria-controls="mainNavbar" aria-expanded="false" aria-label="Buka navigasi">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mainNavbar">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <?php foreach ($navigationLinks as $key => $link): ?>
                        <li class="nav-item">
                            <a class="nav-link<?= $activePage === $key ? ' active' : '' ?>" href="<?= htmlspecialchars($link['href'], ENT_QUOTES, 'UTF-8') ?>"<?= $activePage === $key ? ' aria-current="page"' : '' ?>>
                                <?= htmlspecialchars($link['label'], ENT_QUOTES, 'UTF-8') ?>
                            </a>
                        </li>
                    <?php endforeach; ?>
                    <li class="nav-item"><a class="nav-link" href="https://www.linkedin.com/in/syahrul-mubarok-487057448/" target="_blank" rel="noopener noreferrer">LinkedIn Saya</a></li>
                </ul>
            </div>
        </div>
    </nav>
