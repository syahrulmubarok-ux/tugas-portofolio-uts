<?php
return [
    'aboutme' => ['label' => 'About Me', 'href' => 'aboutme.php'],
    'karir' => ['label' => 'Riwayat Karir', 'href' => 'karir.php'],
    'prestasi' => ['label' => 'Prestasi Sekolah', 'href' => 'prestasi.php'],
    'kontak' => ['label' => 'Kontak', 'href' => 'kontak.php'],
];
