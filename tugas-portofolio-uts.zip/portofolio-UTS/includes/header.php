<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=3">
</head>
<body>
    <header>
        <h1>Portofolio Saya</h1>
        <form action="search.php" method="GET">
            <input type="text" name="keyword" placeholder="Cari artikel/karir..." required>
            <button type="submit" class="btn-submit">Cari</button>
        </form>
    </header>
