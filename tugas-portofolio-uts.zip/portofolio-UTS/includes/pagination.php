<?php
$sitePages = require __DIR__ . '/site-pages.php';
$pageKeys = array_keys($sitePages);
$currentIndex = array_search($activePage, $pageKeys, true);
$previousPage = $currentIndex !== false && $currentIndex > 0
    ? $sitePages[$pageKeys[$currentIndex - 1]]
    : null;
$nextPage = $currentIndex !== false && $currentIndex < count($pageKeys) - 1
    ? $sitePages[$pageKeys[$currentIndex + 1]]
    : null;
$pageNumber = 0;
?>
    <nav class="site-pagination" aria-label="Navigasi halaman situs">
        <ul class="pagination justify-content-center mb-0">
            <li class="page-item<?= $previousPage === null ? ' disabled' : '' ?>">
                <?php if ($previousPage !== null): ?>
                    <a class="page-link" href="<?= htmlspecialchars($previousPage['href'], ENT_QUOTES, 'UTF-8') ?>" aria-label="Halaman sebelumnya">&lsaquo;</a>
                <?php else: ?>
                    <span class="page-link" aria-label="Tidak ada halaman sebelumnya" aria-disabled="true">&lsaquo;</span>
                <?php endif; ?>
            </li>

            <?php foreach ($sitePages as $key => $page): ?>
                <?php $pageNumber++; ?>
                <li class="page-item<?= $activePage === $key ? ' active' : '' ?>">
                    <a class="page-link" href="<?= htmlspecialchars($page['href'], ENT_QUOTES, 'UTF-8') ?>"<?= $activePage === $key ? ' aria-current="page"' : '' ?> aria-label="<?= htmlspecialchars($page['label'], ENT_QUOTES, 'UTF-8') ?>"><?= $pageNumber ?></a>
                </li>
            <?php endforeach; ?>

            <li class="page-item<?= $nextPage === null ? ' disabled' : '' ?>">
                <?php if ($nextPage !== null): ?>
                    <a class="page-link" href="<?= htmlspecialchars($nextPage['href'], ENT_QUOTES, 'UTF-8') ?>" aria-label="Halaman berikutnya">&rsaquo;</a>
                <?php else: ?>
                    <span class="page-link" aria-label="Tidak ada halaman berikutnya" aria-disabled="true">&rsaquo;</span>
                <?php endif; ?>
            </li>
        </ul>
    </nav>
